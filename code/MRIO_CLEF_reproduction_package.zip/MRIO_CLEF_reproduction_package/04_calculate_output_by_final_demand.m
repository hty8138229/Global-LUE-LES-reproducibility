%% 04_calculate_output_by_final_demand.m
% Calculate the region-sector output induced by final demand:
%   X_by_final_demand = L * Y
%
% Inputs:
%   output/Leontief_inverse.csv
%   input/Y_by_country.csv
%
% Outputs:
%   output/X_by_final_demand.csv
%   output/X_total_by_sector.csv

clear; clc;

input_dir = fullfile(pwd, 'input');
output_dir = fullfile(pwd, 'output');

L_file = fullfile(output_dir, 'Leontief_inverse.csv');
Y_file = fullfile(input_dir, 'Y_by_country.csv');
X_fd_out = fullfile(output_dir, 'X_by_final_demand.csv');
X_total_out = fullfile(output_dir, 'X_total_by_sector.csv');

Ltbl = readtable(L_file, 'TextType', 'string');
Ytbl = readtable(Y_file, 'TextType', 'string');

is_meta_L = ismember(Ltbl.Properties.VariableNames, {'region', 'sector', 'Region', 'Sector'});
is_meta_Y = ismember(Ytbl.Properties.VariableNames, {'region', 'sector', 'Region', 'Sector'});

L_vars = Ltbl.Properties.VariableNames(~is_meta_L);
Y_vars = Ytbl.Properties.VariableNames(~is_meta_Y);

if height(Ltbl) ~= height(Ytbl)
    error('L and Y have different numbers of rows.');
end

L_region = string(Ltbl{:, find(is_meta_L, 1, 'first')});
Y_region = string(Ytbl{:, find(is_meta_Y, 1, 'first')});
if any(L_region ~= Y_region)
    error('The row order of L and Y is not aligned.');
end

L_num = Ltbl{:, L_vars};
Y_num = Ytbl{:, Y_vars};
L_num(~isfinite(L_num)) = 0;
Y_num(~isfinite(Y_num)) = 0;

if size(L_num, 1) ~= size(L_num, 2)
    error('L is not a square matrix.');
end
if size(Y_num, 1) ~= size(L_num, 1)
    error('Y rows do not match L dimensions.');
end

if nnz(L_num) < 0.2 * numel(L_num)
    Lm = sparse(L_num);
else
    Lm = L_num;
end

X_by_final_demand = Lm * Y_num;
X_total = sum(X_by_final_demand, 2, 'omitnan');

Xtbl = Ytbl(:, is_meta_Y);
Xtbl = [Xtbl, array2table(full(X_by_final_demand), 'VariableNames', Y_vars)];
writetable(Xtbl, X_fd_out);

Xsumtbl = Ytbl(:, is_meta_Y);
Xsumtbl.X_total = full(X_total);
writetable(Xsumtbl, X_total_out);

fprintf('Saved output induced by final demand to %s\n', X_fd_out);
fprintf('Saved total output by sector to %s\n', X_total_out);

