# Input Folder

Place the required input files for one assessment year in this folder before running `run_MRIO_CLEF_workflow.m`.

Required files:

| File | Required columns |
|---|---|
| `Z.csv` | `region`, `sector`, followed by the intermediate transaction matrix columns |
| `Y_by_country.csv` | `region`, `sector`, followed by final-demand columns for consuming regions |
| `x.csv` | `region`, `sector`, `x` |
| `F_land_intensity.csv` | `region`, `sector`, `F` |

The rows of all files must follow the same region-sector order.

