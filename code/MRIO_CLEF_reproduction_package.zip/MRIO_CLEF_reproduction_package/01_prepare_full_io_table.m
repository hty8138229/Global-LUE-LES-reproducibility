%% 01_prepare_full_io_table.m
% Prepare a combined MRIO table from EXIOBASE Z, Y, and x files.
%
% Required inputs:
%   input/Z.csv
%   input/Y_by_country.csv
%   input/x.csv
%
% Expected structure:
%   The first two columns of each file are region and sector.
%   Remaining columns are numerical data.
%
% Output:
%   output/Full_IO_Table.csv

clear; clc;

input_dir = fullfile(pwd, 'input');
output_dir = fullfile(pwd, 'output');
if ~exist(output_dir, 'dir')
    mkdir(output_dir);
end

Z_file = fullfile(input_dir, 'Z.csv');
Y_file = fullfile(input_dir, 'Y_by_country.csv');
x_file = fullfile(input_dir, 'x.csv');
output_file = fullfile(output_dir, 'Full_IO_Table.csv');

Z_table = readtable(Z_file, 'TextType', 'string');
Y_table = readtable(Y_file, 'TextType', 'string');
x_table = readtable(x_file, 'TextType', 'string');

Z_key = Z_table(:, 1:2);
Y_key = Y_table(:, 1:2);
x_key = x_table(:, 1:2);

if ~isequal(table2cell(Z_key), table2cell(Y_key)) || ~isequal(table2cell(Z_key), table2cell(x_key))
    error('The region-sector keys in Z, Y, and x are not identical.');
end

Z_data = Z_table(:, 3:end);
Y_data = Y_table(:, 3:end);
x_data = x_table(:, 3);

Z_data.Properties.VariableNames = matlab.lang.makeUniqueStrings(strcat("Z_", string(Z_data.Properties.VariableNames)));
Y_data.Properties.VariableNames = matlab.lang.makeUniqueStrings(strcat("Y_", string(Y_data.Properties.VariableNames)));
x_data.Properties.VariableNames = {'x'};

Full_IO_Table = [Z_key, Z_data, Y_data, x_data];
writetable(Full_IO_Table, output_file);

fprintf('Saved combined MRIO table to %s\n', output_file);

