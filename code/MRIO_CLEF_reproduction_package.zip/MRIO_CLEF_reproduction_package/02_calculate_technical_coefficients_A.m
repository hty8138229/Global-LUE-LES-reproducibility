%% 02_calculate_technical_coefficients_A.m
% Calculate the MRIO technical coefficient matrix:
%   A_ij = Z_ij / x_j
%
% Input:
%   output/Full_IO_Table.csv
%
% Output:
%   output/A_matrix.csv

clear; clc;

output_dir = fullfile(pwd, 'output');
input_file = fullfile(output_dir, 'Full_IO_Table.csv');
output_file = fullfile(output_dir, 'A_matrix.csv');

T = readtable(input_file, 'TextType', 'string');
vars = T.Properties.VariableNames;

is_meta = ismember(vars, {'region', 'sector', 'Region', 'Sector'});
is_Y = startsWith(vars, 'Y_');
is_x = strcmp(vars, 'x');
is_Z = startsWith(vars, 'Z_');

if ~any(is_x)
    error('The total output column x was not found.');
end

Z_vars = vars(is_Z);
if isempty(Z_vars)
    error('No Z columns were found. Z columns should start with "Z_".');
end

meta = T(:, is_meta);
Z = T{:, Z_vars};
x = T{:, is_x};

[nr, nc] = size(Z);
if nr ~= nc
    error('Z is not a square matrix: %d x %d.', nr, nc);
end
if length(x) ~= nc
    error('The length of x does not match the number of Z columns.');
end

x_row = x(:)';
A = Z ./ x_row;
A(:, x == 0 | isnan(x)) = 0;
A(~isfinite(A)) = 0;

A_tbl = array2table(A, 'VariableNames', Z_vars);
T_out = [meta, A_tbl];
writetable(T_out, output_file);

fprintf('Saved technical coefficient matrix A to %s\n', output_file);

