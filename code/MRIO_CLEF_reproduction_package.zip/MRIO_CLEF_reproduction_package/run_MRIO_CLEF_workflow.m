%% run_MRIO_CLEF_workflow.m
% Run the complete MRIO-CLEF reproduction workflow.
%
% Before running this script, place the required input files in the input folder:
%   input/Z.csv
%   input/Y_by_country.csv
%   input/x.csv
%   input/F_land_intensity.csv

clear; clc;

fprintf('Running MRIO-CLEF workflow...\n');

run('01_prepare_full_io_table.m');
run('02_calculate_technical_coefficients_A.m');
run('03_calculate_leontief_inverse.m');
run('04_calculate_output_by_final_demand.m');
run('05_calculate_CLEF_and_bilateral_flows.m');

fprintf('MRIO-CLEF workflow completed.\n');

