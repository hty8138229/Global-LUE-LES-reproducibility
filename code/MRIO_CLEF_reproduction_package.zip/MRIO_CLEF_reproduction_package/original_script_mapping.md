# Original Script Mapping

The uploaded MATLAB files were temporary working scripts. The table below identifies which files are part of the MRIO-CLEF calculation chain and how they were reorganized.

| Uploaded file | Role in original workflow | Included in clean package |
|---|---|---|
| `UntitledIO.m` | Combined EXIOBASE Z, Y, and x files into a full IO table. | `01_prepare_full_io_table.m` |
| `UntitledA.m` | Calculated the technical coefficient matrix A from Z and x. | `02_calculate_technical_coefficients_A.m` |
| `UntitledNI.m` | Alternative script for calculating A and the Leontief inverse directly. | Partly covered by scripts 02 and 03 |
| `Untitledleon(1).m` | Calculated the Leontief inverse matrix. | `03_calculate_leontief_inverse.m` |
| `UntitledleonY(1).m` | Multiplied the Leontief inverse by final demand. | `04_calculate_output_by_final_demand.m` |
| `UntitledF(1).m` | Multiplied output induced by final demand by land footprint intensity and aggregated to bilateral EF flows. | `05_calculate_CLEF_and_bilateral_flows.m` |
| `UntitledRR(1).m` | Aggregated region-sector results to a country-by-country matrix. | Covered by script 05 |
| `UntitledDN.m` / `UntitledNIDN` / `Untitledend.m` | Alternative or exploratory scripts for final-demand vector and Leontief multiplication. | Not included in main workflow |
| `Untitledcs.m` / `Untitledx.m` / `UntitledY.m` / `UntitledZ.m` / `Untitledexio(1).m` | File conversion and EXIOBASE formatting helpers. | Not included in main workflow; can be retained as auxiliary conversion scripts if needed |
| `Untitled3.m` / `Untitled4.m` | EDGAR/emissions preprocessing scripts for air pollutants. | Not part of MRIO-CLEF calculation |
| `Untitledsum(1).m` | Simple country-level summation script for an unrelated dataset. | Not part of MRIO-CLEF calculation |

