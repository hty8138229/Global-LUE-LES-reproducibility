# MRIO-CLEF Reproduction Instructions

This folder provides the MATLAB scripts and reproduction notes used to calculate consumption-based land ecological footprint (CLEF) with an environmentally extended multi-regional input-output (MRIO) framework.

## 1. Purpose

The scripts reproduce the MRIO-based calculation chain from EXIOBASE input-output data and land footprint intensities to:

- sectoral ecological footprint induced by final demand;
- bilateral ecological footprint flows among regions;
- production-based land ecological footprint (PLEF);
- consumption-based land ecological footprint (CLEF).

## 2. Required Input Files

The scripts assume that EXIOBASE and the processed land footprint intensity data have already been prepared for each assessment year.

| File | Description |
|---|---|
| `Z.csv` | Intermediate transaction matrix from EXIOBASE. Rows and columns are region-sector observations. |
| `Y_by_country.csv` | Final demand matrix aggregated by consuming region. Rows are region-sector observations and columns are consuming regions. |
| `x.csv` | Total output vector from EXIOBASE. |
| `F_land_intensity.csv` | Land footprint intensity by producing region and sector. |

The EXIOBASE source database is not redistributed here. Users should obtain EXIOBASE from its official source and format the files according to the structure described above.

## 3. Main Workflow

Run the scripts in the following order for each assessment year:

1. `01_prepare_full_io_table.m`
2. `02_calculate_technical_coefficients_A.m`
3. `03_calculate_leontief_inverse.m`
4. `04_calculate_output_by_final_demand.m`
5. `05_calculate_CLEF_and_bilateral_flows.m`

The workflow is:

```text
Z, Y, x
  -> A = Z * diag(x)^(-1)
  -> L = (I - A)^(-1)
  -> X_by_final_demand = L * Y
  -> EF_by_sector_and_final_demand = F * X_by_final_demand
  -> PLEF, CLEF, and bilateral EF flows
```

## 4. MRIO Calculation

For each year, the technical coefficient matrix is calculated as:

```text
A_ij = Z_ij / x_j
```

The Leontief inverse is calculated as:

```text
L = (I - A)^(-1)
```

The output induced by final demand is calculated as:

```text
X_by_final_demand = L * Y
```

The ecological footprint induced by final demand is calculated as:

```text
EF_by_sector_and_final_demand = F .* X_by_final_demand
```

where `F` is the land footprint intensity vector by producing region-sector. The resulting matrix is then aggregated from sector level to country or region level.

## 5. Output Files

| Output file | Description |
|---|---|
| `Full_IO_Table.csv` | Combined region-sector table containing Z, Y, and x. |
| `A_matrix.csv` | Technical coefficient matrix. |
| `Leontief_inverse.csv` | Leontief inverse matrix. |
| `X_by_final_demand.csv` | Region-sector output induced by each consuming region's final demand. |
| `EF_sector_by_final_demand.csv` | Region-sector ecological footprint induced by each consuming region's final demand. |
| `EF_flow_country_by_country.csv` | Bilateral ecological footprint flow matrix. Rows represent producing regions and columns represent consuming regions. |
| `PLEF_CLEF_by_region.csv` | PLEF and CLEF results by region. |

## 6. Interpretation of the Bilateral Flow Matrix

The bilateral flow matrix is organized as:

```text
rows    = producing/source regions
columns = consuming/destination regions
```

Therefore:

```text
PLEF_i = sum_j Flow_ij
CLEF_j = sum_i Flow_ij
```

The row sums of the bilateral flow matrix correspond to production-based land ecological footprint (PLEF). The column sums correspond to consumption-based land ecological footprint (CLEF).

## 7. Software

The scripts were written for MATLAB. They use only standard MATLAB table and matrix operations, including `readtable`, `writetable`, sparse matrix operations, and matrix left division.

## 8. Notes on Original Scripts

The uploaded working scripts originally had temporary names such as `UntitledIO.m`, `UntitledA.m`, `Untitledleon(1).m`, `UntitledleonY(1).m`, `UntitledF(1).m`, and `UntitledRR(1).m`. These have been reorganized into a clean workflow with descriptive file names. Temporary scripts used only for data conversion or unrelated emissions preprocessing were not included in the main reproduction workflow.

