%% 03_calculate_leontief_inverse.m
% Calculate the Leontief inverse:
%   L = (I - A)^(-1)
%
% Input:
%   output/A_matrix.csv
%
% Outputs:
%   output/Leontief_inverse.csv
%   output/Leontief_inverse.mat

clear; clc;

output_dir = fullfile(pwd, 'output');
input_file = fullfile(output_dir, 'A_matrix.csv');
output_csv = fullfile(output_dir, 'Leontief_inverse.csv');
output_mat = fullfile(output_dir, 'Leontief_inverse.mat');

T = readtable(input_file, 'TextType', 'string');
vars = T.Properties.VariableNames;

is_meta = ismember(vars, {'region', 'sector', 'Region', 'Sector'});
A_vars = vars(~is_meta);
meta = T(:, is_meta);
A_full = T{:, A_vars};
A_full(~isfinite(A_full)) = 0;

[nr, nc] = size(A_full);
if nr ~= nc
    error('A is not a square matrix: %d x %d.', nr, nc);
end

if nnz(A_full) < 0.2 * numel(A_full)
    A = sparse(A_full);
else
    A = A_full;
end

I = speye(nc);
M = I - A;

try
    L = M \ I;
catch ME
    warning('Matrix left division failed; using pinv instead. MATLAB message: %s', ME.message);
    L = full(pinv(full(M)));
end

L_tbl = array2table(full(L), 'VariableNames', A_vars);
T_out = [meta, L_tbl];
writetable(T_out, output_csv);
save(output_mat, 'L', 'A_vars', 'T_out', '-v7.3');

fprintf('Saved Leontief inverse to %s and %s\n', output_csv, output_mat);

