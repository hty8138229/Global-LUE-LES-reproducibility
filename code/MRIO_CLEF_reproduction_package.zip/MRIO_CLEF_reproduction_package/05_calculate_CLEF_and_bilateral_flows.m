%% 05_calculate_CLEF_and_bilateral_flows.m
% Calculate sectoral ecological footprint, bilateral flow matrix, PLEF, and CLEF.
%
% Inputs:
%   output/X_by_final_demand.csv
%   input/F_land_intensity.csv
%
% Required structure of F_land_intensity.csv:
%   region, sector, F
%
% Outputs:
%   output/EF_sector_by_final_demand.csv
%   output/EF_flow_country_by_country.csv
%   output/PLEF_CLEF_by_region.csv
%   output/EF_flow_checks.csv

clear; clc;

input_dir = fullfile(pwd, 'input');
output_dir = fullfile(pwd, 'output');

X_file = fullfile(output_dir, 'X_by_final_demand.csv');
F_file = fullfile(input_dir, 'F_land_intensity.csv');

EF_sector_out = fullfile(output_dir, 'EF_sector_by_final_demand.csv');
Flow_out = fullfile(output_dir, 'EF_flow_country_by_country.csv');
PLEF_CLEF_out = fullfile(output_dir, 'PLEF_CLEF_by_region.csv');
Checks_out = fullfile(output_dir, 'EF_flow_checks.csv');

Xtbl = readtable(X_file, 'TextType', 'string');
Ftbl = readtable(F_file, 'TextType', 'string');

varsX = Xtbl.Properties.VariableNames;
varsF = Ftbl.Properties.VariableNames;

is_meta_X = ismember(varsX, {'region', 'sector', 'Region', 'Sector'});
is_meta_F = ismember(varsF, {'region', 'sector', 'Region', 'Sector'});

idx_region_X = find(ismember(varsX, {'region', 'Region'}), 1);
idx_sector_X = find(ismember(varsX, {'sector', 'Sector'}), 1);
idx_region_F = find(ismember(varsF, {'region', 'Region'}), 1);
idx_sector_F = find(ismember(varsF, {'sector', 'Sector'}), 1);

if isempty(idx_region_X) || isempty(idx_sector_X) || isempty(idx_region_F) || isempty(idx_sector_F)
    error('Both X and F files must contain region and sector columns.');
end

idx_F = find(strcmpi(varsF, 'F'), 1);
if isempty(idx_F)
    error('F_land_intensity.csv must contain a column named F.');
end

regX = string(strtrim(Xtbl{:, idx_region_X}));
secX = string(strtrim(Xtbl{:, idx_sector_X}));
regF = string(strtrim(Ftbl{:, idx_region_F}));
secF = string(strtrim(Ftbl{:, idx_sector_F}));

if height(Xtbl) ~= height(Ftbl) || any(regX ~= regF) || any(secX ~= secF)
    error('X_by_final_demand and F_land_intensity are not aligned by region-sector rows.');
end

FD_vars = varsX(~is_meta_X);
X_num = Xtbl{:, FD_vars};
F_vec = Ftbl{:, idx_F};
X_num(~isfinite(X_num)) = 0;
F_vec(~isfinite(F_vec)) = 0;

consumer_regions = regexprep(string(FD_vars(:)), '^(Y_|X_Y_|X_)', '');
flow_colnames = matlab.lang.makeValidName(consumer_regions);
flow_colnames = matlab.lang.makeUniqueStrings(flow_colnames);

EF_sector_fd = X_num .* F_vec;

EF_tbl = Xtbl(:, is_meta_X);
EF_tbl = [EF_tbl, array2table(EF_sector_fd, 'VariableNames', FD_vars)];
writetable(EF_tbl, EF_sector_out);

[producer_regions, ~] = unique(regX, 'stable');
R = numel(producer_regions);
K = numel(FD_vars);

Flow = zeros(R, K);
for r = 1:R
    rows = regX == producer_regions(r);
    Flow(r, :) = sum(EF_sector_fd(rows, :), 1, 'omitnan');
end

Flow_tbl = array2table(Flow, 'VariableNames', cellstr(flow_colnames));
Flow_tbl.region = producer_regions;
Flow_tbl = movevars(Flow_tbl, 'region', 'Before', 1);
writetable(Flow_tbl, Flow_out);

PLEF = sum(Flow, 2, 'omitnan');
CLEF = sum(Flow, 1, 'omitnan')';

if numel(CLEF) ~= R
    consumer_regions = "FD_" + string((1:K)');
end

PLEF_tbl = table(producer_regions, PLEF, 'VariableNames', {'Region', 'PLEF'});
CLEF_tbl = table(consumer_regions, CLEF, 'VariableNames', {'Region', 'CLEF'});

if height(PLEF_tbl) == height(CLEF_tbl)
    Result = table(PLEF_tbl.Region, PLEF_tbl.PLEF, CLEF_tbl.CLEF, ...
        'VariableNames', {'Region', 'PLEF', 'CLEF'});
else
    Result = outerjoin(PLEF_tbl, CLEF_tbl, 'Keys', 'Region', 'MergeKeys', true);
end
writetable(Result, PLEF_CLEF_out);

global_row_sum = sum(PLEF, 'omitnan');
global_col_sum = sum(CLEF, 'omitnan');
global_diff = global_row_sum - global_col_sum;

Checks = table(global_row_sum, global_col_sum, global_diff, ...
    'VariableNames', {'Global_PLEF_sum', 'Global_CLEF_sum', 'Difference'});
writetable(Checks, Checks_out);

fprintf('Saved sectoral EF results to %s\n', EF_sector_out);
fprintf('Saved bilateral EF flow matrix to %s\n', Flow_out);
fprintf('Saved PLEF and CLEF results to %s\n', PLEF_CLEF_out);
fprintf('Global PLEF - CLEF difference = %.12g\n', global_diff);
