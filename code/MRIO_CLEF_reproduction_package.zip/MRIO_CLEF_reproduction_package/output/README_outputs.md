# Output Folder

The reproduction scripts write generated files to this folder.

Expected outputs:

| File | Description |
|---|---|
| `Full_IO_Table.csv` | Combined MRIO table |
| `A_matrix.csv` | Technical coefficient matrix |
| `Leontief_inverse.csv` | Leontief inverse matrix |
| `X_by_final_demand.csv` | Output induced by final demand |
| `EF_sector_by_final_demand.csv` | Sectoral ecological footprint by consuming region |
| `EF_flow_country_by_country.csv` | Bilateral ecological footprint flow matrix |
| `PLEF_CLEF_by_region.csv` | Production-based and consumption-based land ecological footprint by region |
| `EF_flow_checks.csv` | Internal consistency checks |

