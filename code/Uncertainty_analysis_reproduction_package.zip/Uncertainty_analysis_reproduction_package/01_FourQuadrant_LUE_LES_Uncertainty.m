%% FourQuadrant_LUE_LES_Uncertainty.m
% This script calculates the stability of the four-quadrant LUE-LES
% classification under Monte Carlo parameter perturbations.
%
% Required Excel workbook structure:
%   Sheet 1: baseline
%       Columns: Region, Year, LUE_base, PLEF_base, LBC_base
%       Acceptable alternatives: LUE / Baseline_LUE, PLEF / EFp, LBC
%
%   Sheet 2: LUE_MC
%       Columns: Region, Year, MC_1, MC_2, ..., MC_1000
%
%   Sheet 3: PLEF_MC
%       Columns: Region, Year, MC_1, MC_2, ..., MC_1000
%
%   Sheet 4: LBC_MC
%       Columns: Region, Year, MC_1, MC_2, ..., MC_1000
%
% Output:
%   Quadrant_uncertainty_results.xlsx
%       Sheet: Detailed_results
%       Sheet: Summary
%       Sheet: Unstable_observations
%       Sheet: Representative_regions
%
% Notes:
%   LUE threshold = 1
%   LES threshold = LBC / PLEF = 1
%   Four quadrants:
%       Efficient-secure      : LUE >= 1 and LBC/PLEF >= 1
%       Inefficient-secure    : LUE <  1 and LBC/PLEF >= 1
%       Efficient-stressed    : LUE >= 1 and LBC/PLEF <  1
%       Inefficient-stressed  : LUE <  1 and LBC/PLEF <  1

clear; clc;

fprintf('\n=== Four-quadrant LUE-LES uncertainty analysis ===\n');

%% 1. Select input Excel file
[fileName, filePath] = uigetfile({'*.xlsx;*.xls', 'Excel files (*.xlsx, *.xls)'}, ...
    'Select Monte Carlo result workbook');

if isequal(fileName, 0)
    error('No input file selected. Please select an Excel workbook.');
end

inputFile = fullfile(filePath, fileName);
fprintf('Input file: %s\n', inputFile);

%% 2. Read required sheets
base   = readExcelSheet(inputFile, 'baseline');
lueMC  = readExcelSheet(inputFile, 'LUE_MC');
plefMC = readExcelSheet(inputFile, 'PLEF_MC');
lbcMC  = readExcelSheet(inputFile, 'LBC_MC');

%% 3. Identify columns in baseline sheet
regionCol_base = findColumn(base, {'Region', 'region', 'Code', 'code', 'Country', 'country'});
yearCol_base   = findColumn(base, {'Year', 'year'});
lueCol_base    = findColumn(base, {'LUE_base', 'Baseline_LUE', 'LUE', 'lue'});
plefCol_base   = findColumn(base, {'PLEF_base', 'Baseline_PLEF', 'PLEF', 'EFp', 'LEF', 'plef'});
lbcCol_base    = findColumn(base, {'LBC_base', 'Baseline_LBC', 'LBC', 'lbc'});

Region = makeStringColumn(base.(regionCol_base));
Year   = base.(yearCol_base);

if iscell(Year) || isstring(Year) || iscategorical(Year)
    Year = str2double(string(Year));
end

LUE_base  = base.(lueCol_base);
PLEF_base = base.(plefCol_base);
LBC_base  = base.(lbcCol_base);

LUE_base  = double(LUE_base);
PLEF_base = double(PLEF_base);
LBC_base  = double(LBC_base);

if any(PLEF_base <= 0 | isnan(PLEF_base))
    error('PLEF_base contains zero, negative, or missing values. LES = LBC/PLEF cannot be calculated.');
end

LES_base = LBC_base ./ PLEF_base;

%% 4. Extract and align Monte Carlo matrices
[LUE_sim,  Region_lue,  Year_lue]  = extractMCMat(lueMC);
[PLEF_sim, Region_plef, Year_plef] = extractMCMat(plefMC);
[LBC_sim,  Region_lbc,  Year_lbc]  = extractMCMat(lbcMC);

% Align MC tables to baseline order by Region-Year keys
[LUE_sim,  nSim_LUE]  = alignMCMatrix(LUE_sim,  Region_lue,  Year_lue,  Region, Year, 'LUE_MC');
[PLEF_sim, nSim_PLEF] = alignMCMatrix(PLEF_sim, Region_plef, Year_plef, Region, Year, 'PLEF_MC');
[LBC_sim,  nSim_LBC]  = alignMCMatrix(LBC_sim,  Region_lbc,  Year_lbc,  Region, Year, 'LBC_MC');

if ~(nSim_LUE == nSim_PLEF && nSim_LUE == nSim_LBC)
    error('The number of Monte Carlo simulations is inconsistent across LUE_MC, PLEF_MC, and LBC_MC.');
end

nObs = numel(Region);
nSim = nSim_LUE;

fprintf('Number of region-year observations: %d\n', nObs);
fprintf('Number of Monte Carlo simulations: %d\n', nSim);

if any(PLEF_sim(:) <= 0 | isnan(PLEF_sim(:)))
    error('PLEF_MC contains zero, negative, or missing values. Simulated LES = LBC/PLEF cannot be calculated.');
end

LES_sim = LBC_sim ./ PLEF_sim;

%% 5. Define baseline and simulated quadrants
Q_base = classifyQuadrant(LUE_base, LES_base);
Q_sim  = strings(nObs, nSim);

for j = 1:nSim
    Q_sim(:, j) = classifyQuadrant(LUE_sim(:, j), LES_sim(:, j));
end

%% 6. Calculate quadrant-retention probability
retain = false(nObs, nSim);
for j = 1:nSim
    retain(:, j) = (Q_sim(:, j) == Q_base);
end

QuadrantRetentionProb = mean(retain, 2, 'omitnan');

%% 7. Calculate simulated quadrant frequencies
EfficientSecure_freq     = mean(Q_sim == "Efficient-secure", 2, 'omitnan');
InefficientSecure_freq   = mean(Q_sim == "Inefficient-secure", 2, 'omitnan');
EfficientStressed_freq   = mean(Q_sim == "Efficient-stressed", 2, 'omitnan');
InefficientStressed_freq = mean(Q_sim == "Inefficient-stressed", 2, 'omitnan');

%% 8. Identify near-threshold observations
DistanceToLUEThreshold = abs(LUE_base - 1);
DistanceToLESThreshold = abs(LES_base - 1);
MinimumThresholdDistance = min(DistanceToLUEThreshold, DistanceToLESThreshold);

% The threshold 0.05 can be adjusted if needed.
NearLUEThreshold = DistanceToLUEThreshold < 0.05;
NearLESThreshold = DistanceToLESThreshold < 0.05;
NearAnyThreshold = NearLUEThreshold | NearLESThreshold;

%% 9. Detailed result table
Result = table( ...
    Region, Year, ...
    LUE_base, PLEF_base, LBC_base, LES_base, Q_base, ...
    QuadrantRetentionProb, ...
    EfficientSecure_freq, InefficientSecure_freq, ...
    EfficientStressed_freq, InefficientStressed_freq, ...
    DistanceToLUEThreshold, DistanceToLESThreshold, ...
    MinimumThresholdDistance, NearLUEThreshold, NearLESThreshold, NearAnyThreshold);

%% 10. Summary table for Supplementary Information
Summary = table;
Summary.Indicator = [
    "Number of region-year observations";
    "Number of Monte Carlo simulations";
    "Mean quadrant-retention probability";
    "Median quadrant-retention probability";
    "Minimum quadrant-retention probability";
    "Maximum quadrant-retention probability";
    "Observations with retention probability above 0.90";
    "Observations with retention probability above 0.75";
    "Observations with retention probability below 0.50";
    "Observations near LUE threshold, |LUE-1| < 0.05";
    "Observations near LES threshold, |LBC/PLEF-1| < 0.05";
    "Observations near either threshold"
];

Summary.Result = [
    nObs;
    nSim;
    mean(QuadrantRetentionProb, 'omitnan');
    median(QuadrantRetentionProb, 'omitnan');
    min(QuadrantRetentionProb, [], 'omitnan');
    max(QuadrantRetentionProb, [], 'omitnan');
    sum(QuadrantRetentionProb > 0.90);
    sum(QuadrantRetentionProb > 0.75);
    sum(QuadrantRetentionProb < 0.50);
    sum(NearLUEThreshold);
    sum(NearLESThreshold);
    sum(NearAnyThreshold)
];

%% 11. Optional representative regions for response letter
representativeNames = ["CHN", "China", "BRA", "Brazil", "IND", "India", ...
                       "WF", "Rest of Africa", "WA", "Rest of Asia", ...
                       "USA", "United States", "RUS", "Russia", "DEU", "Germany"];

repMask = false(nObs, 1);
for k = 1:numel(representativeNames)
    repMask = repMask | strcmpi(strtrim(Region), representativeNames(k));
end
Representative = Result(repMask, :);

%% 12. Export results
outputFile = fullfile(filePath, 'Quadrant_uncertainty_results.xlsx');

if exist(outputFile, 'file')
    delete(outputFile);
end

writetable(Result, outputFile, 'Sheet', 'Detailed_results');
writetable(Summary, outputFile, 'Sheet', 'Summary');

Unstable = Result(Result.QuadrantRetentionProb < 0.75, :);
writetable(Unstable, outputFile, 'Sheet', 'Unstable_observations');
writetable(Representative, outputFile, 'Sheet', 'Representative_regions');

fprintf('\nAnalysis completed successfully.\n');
fprintf('Output file: %s\n\n', outputFile);

disp(Summary);

%% 13. Suggested wording for manuscript
fprintf('\nSuggested sentence for manuscript after replacing values if needed:\n');
fprintf(['Across all %d region-year observations, the mean quadrant-retention probability was %.3f, ', ...
         'and %d observations retained their baseline quadrant with a probability above 0.90.\n'], ...
         nObs, mean(QuadrantRetentionProb, 'omitnan'), sum(QuadrantRetentionProb > 0.90));

%% ------------------------------------------------------------------------
%% Local functions
%% ------------------------------------------------------------------------

function T = readExcelSheet(inputFile, sheetName)
    try
        T = readtable(inputFile, 'Sheet', sheetName, 'VariableNamingRule', 'preserve');
    catch
        try
            T = readtable(inputFile, 'Sheet', sheetName);
        catch ME
            error('Unable to read sheet "%s" from the selected workbook. Original error: %s', sheetName, ME.message);
        end
    end
end

function colName = findColumn(T, candidates)
    varNames = string(T.Properties.VariableNames);
    normVarNames = normalizeName(varNames);
    normCandidates = normalizeName(string(candidates));

    idx = [];
    for i = 1:numel(normCandidates)
        match = find(normVarNames == normCandidates(i), 1);
        if ~isempty(match)
            idx = match;
            break;
        end
    end

    if isempty(idx)
        error('Required column not found. Tried: %s. Available columns: %s', ...
              strjoin(string(candidates), ', '), strjoin(varNames, ', '));
    end

    colName = T.Properties.VariableNames{idx};
end

function normNames = normalizeName(names)
    names = string(names);
    normNames = lower(names);
    normNames = regexprep(normNames, '[\s_\-\(\)\/\\]+', '');
end

function S = makeStringColumn(x)
    if iscell(x)
        S = string(x);
    elseif iscategorical(x)
        S = string(x);
    elseif isnumeric(x)
        S = string(x);
    else
        S = string(x);
    end
    S = strtrim(S);
end

function [MC, Region, Year] = extractMCMat(T)
    regionCol = findColumn(T, {'Region', 'region', 'Code', 'code', 'Country', 'country'});
    yearCol   = findColumn(T, {'Year', 'year'});

    Region = makeStringColumn(T.(regionCol));
    Year = T.(yearCol);
    if iscell(Year) || isstring(Year) || iscategorical(Year)
        Year = str2double(string(Year));
    end

    varNames = string(T.Properties.VariableNames);
    keyCols = strcmp(varNames, string(regionCol)) | strcmp(varNames, string(yearCol));
    mcCols = find(~keyCols);

    MC = table2array(T(:, mcCols));
    MC = double(MC);

    if isempty(MC)
        error('No Monte Carlo simulation columns found in one of the MC sheets.');
    end
end

function [MC_aligned, nSim] = alignMCMatrix(MC, RegionMC, YearMC, RegionBase, YearBase, sheetLabel)
    keyMC = makeKeys(RegionMC, YearMC);
    keyBase = makeKeys(RegionBase, YearBase);

    [found, loc] = ismember(keyBase, keyMC);

    if any(~found)
        missingKeys = keyBase(~found);
        showN = min(5, numel(missingKeys));
        error('Some baseline Region-Year rows were not found in %s. Examples: %s', ...
              sheetLabel, strjoin(missingKeys(1:showN), '; '));
    end

    MC_aligned = MC(loc, :);
    nSim = size(MC_aligned, 2);
end

function keys = makeKeys(Region, Year)
    keys = strtrim(string(Region)) + "__" + string(double(Year));
end

function Q = classifyQuadrant(LUE, LES)
    Q = strings(size(LUE));

    Q(LUE >= 1 & LES >= 1) = "Efficient-secure";
    Q(LUE <  1 & LES >= 1) = "Inefficient-secure";
    Q(LUE >= 1 & LES <  1) = "Efficient-stressed";
    Q(LUE <  1 & LES <  1) = "Inefficient-stressed";

    Q(isnan(LUE) | isnan(LES)) = "Missing";
end
