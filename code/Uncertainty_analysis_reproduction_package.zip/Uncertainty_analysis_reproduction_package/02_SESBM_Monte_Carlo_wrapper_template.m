%% 02_SESBM_Monte_Carlo_wrapper_template.m
% SE-SBM Monte Carlo wrapper for efficiency uncertainty analysis.
%
% This wrapper documents how perturbed SE-SBM inputs and sampled
% undesirable-output results were passed to the SE-SBM solver.
%
% Important:
%   The original SE-SBM solver functions were obtained from a third party and
%   are not redistributed here. To run this script, users need equivalent
%   SE-SBM solver functions compatible with:
%
%       results    = SBM_V2(data, T, nx, ny, nb, info)
%       results_Ex = SBM_ex(T, info, results)
%
%   or they may replace these two calls with another equivalent implementation
%   of the specified SE-SBM model.

clear; clc; tic;

%% User settings
MC_simulations = 1000;
random_seed = 2026;
rng(random_seed);

input_workbook = fullfile(pwd, 'input', 'SESBM_MC_input_template.xlsx');
output_workbook = fullfile(pwd, 'output', 'SESBM_MC_efficiency_results.xlsx');
output_mat = fullfile(pwd, 'output', 'SESBM_MC_efficiency_results.mat');

if ~exist(fullfile(pwd, 'output'), 'dir')
    mkdir(fullfile(pwd, 'output'));
end

%% Workbook structure
% Sheet: baseline
%   Required columns:
%       ID, Year, cropland, fertilizer, irrigation water, labor, energy,
%       crop production
%
% Sheet: undesirable_output_MC
%   Rows:
%       DMUs in the same order as baseline
%   Columns:
%       MC_1, MC_2, ..., MC_1000

baseline_data = readmatrix(input_workbook, 'Sheet', 'baseline');
undesirable_output_MC = readmatrix(input_workbook, 'Sheet', 'undesirable_output_MC');

n_DMU = size(baseline_data, 1);
Monte_Carlo_result = zeros(n_DMU, MC_simulations);

%% SE-SBM model settings
T = 4;               % Four assessment years pooled under global DEA
nx = 5;              % Inputs: cropland, fertilizer, irrigation water, labor, energy
ny = 1;              % Number of desirable outputs
nb = 1;              % Number of undesirable outputs

info.model = 1;      % 1 = SBM with undesirable output
info.rts = 1;        % 1 = VRS
info.Super = 1;      % 1 = super-efficiency
info.Glob = 1;       % 1 = global DEA
info.Decomp = 1;     % 1 = decomposition output, if required by solver

%% Build data matrix
% Expected order for the third-party solver:
%   ID, Year, inputs, desirable output, undesirable output
%
% Adjust the column indices below to match the final SE-SBM input table.

data = zeros(n_DMU, size(baseline_data, 2) + 1);
data(:, 1:2) = baseline_data(:, 1:2);       % ID and Year

observed_inputs_and_desirable = baseline_data(:, 3:end);

%% Monte Carlo loop
for m = 1:MC_simulations
    % Parameter perturbation for observed inputs and desirable output.
    % The example below applies a uniform multiplicative perturbation from
    % 0.95 to 1.05. Replace this line if the final analysis uses triangular
    % or other distributional assumptions.
    perturbation_factor = 0.95 + 0.10 * rand;
    data(:, 3:(2 + size(observed_inputs_and_desirable, 2))) = ...
        perturbation_factor * observed_inputs_and_desirable;

    % Sample one undesirable-output realization from the Crystal Ball results.
    sample_id = randi(size(undesirable_output_MC, 2));
    data(:, end) = undesirable_output_MC(:, sample_id);

    % Run SE-SBM model using the third-party or equivalent solver.
    results = SBM_V2(data, T, nx, ny, nb, info);
    results_Ex = SBM_ex(T, info, results);

    % Extract efficiency scores.
    % Adjust the extraction line if the solver output structure differs.
    Monte_Carlo_result(:, m) = cell2mat(results_Ex.Efficiency(2:(n_DMU + 1), 3));
end

save(output_mat, 'Monte_Carlo_result', 'info', 'MC_simulations', 'random_seed');
writematrix(Monte_Carlo_result, output_workbook, 'Sheet', 'LUE_MC', 'Range', 'C2');

boxplot(Monte_Carlo_result');
title('Monte Carlo distribution of SE-SBM efficiency scores');
ylabel('LUE score');

toc;
