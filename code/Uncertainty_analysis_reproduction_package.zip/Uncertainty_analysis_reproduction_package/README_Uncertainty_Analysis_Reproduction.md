# Uncertainty Analysis Reproduction Instructions

This folder provides the available reproduction materials for the uncertainty analysis. The uncertainty assessment combines spreadsheet-based Monte Carlo simulations, SE-SBM efficiency recalculation under parameter perturbations, and four-quadrant LUE-LES classification stability analysis.

## 1. Scope of the Uncertainty Analysis

The uncertainty analysis was designed as a parameter-perturbation and classification-stability assessment. It does not represent a full propagation of all possible sources of uncertainty in the underlying databases and models.

The following uncertainty components were considered:

| Component | Implementation | Materials provided |
|---|---|---|
| Environmental impact and footprint calculations | Spreadsheet calculations with Crystal Ball Monte Carlo simulation | Crystal Ball settings and 1000 simulated environmental impact/footprint outputs should be provided as Excel workbooks |
| SE-SBM efficiency recalculation | Parameter perturbation of input/desirable-output variables and sampled undesirable-output results | SE-SBM Monte Carlo wrapper/operation script |
| LUE-LES four-quadrant stability | Reclassification using simulated LUE, PLEF, and LBC values | MATLAB script `01_FourQuadrant_LUE_LES_Uncertainty.m` |

## 2. Important Code Availability Note

The original SE-SBM solver routine used to calculate efficiency scores was obtained from a third party and is not redistributed because it is not licensed for public redistribution. Therefore, this package does not include the proprietary solver functions such as `SBM_V2` and `SBM_ex`.

To support reproducibility, the package provides:

- processed Monte Carlo input and output requirements;
- the SE-SBM Monte Carlo wrapper showing how perturbed inputs and sampled undesirable outputs were passed to the SE-SBM solver;
- model settings used in the wrapper;
- four-quadrant LUE-LES classification stability code;
- clear instructions for reproducing the analysis using any equivalent implementation of the specified SE-SBM model.

## 3. Required Data Files

The following files should be provided with the uncertainty-analysis materials:

| File | Description |
|---|---|
| `CrystalBall_environmental_impact_MC_outputs.xlsx` | 1000 Monte Carlo simulated environmental-impact or undesirable-output results generated from the spreadsheet/Crystal Ball workflow |
| `CrystalBall_footprint_MC_outputs.xlsx` | 1000 Monte Carlo simulated PLEF and LBC results, if footprint uncertainty is included |
| `SESBM_MC_input_template.xlsx` | Input workbook used by the SE-SBM Monte Carlo wrapper |
| `LUE_PLEF_LBC_MC_for_quadrants.xlsx` | Workbook containing baseline LUE, PLEF, LBC and their Monte Carlo results for four-quadrant stability analysis |

The exact file names may be changed, but the workbook structure should be documented.

## 4. Crystal Ball Spreadsheet Uncertainty

The environmental impact and footprint calculations were implemented in Excel. Monte Carlo simulations were performed using Crystal Ball by perturbing key spreadsheet parameters and recording the resulting environmental impact, PLEF, LBC, or related outputs.

Because these calculations were performed in Excel rather than as standalone scripts, the reproducibility materials should include:

1. the Excel workbooks containing the formulas;
2. the Crystal Ball assumption settings;
3. the generated 1000 simulation outputs;
4. a note identifying the perturbed parameters and their distributions.

The manuscript should state that this represents parameter perturbation rather than comprehensive uncertainty propagation.

## 5. SE-SBM Monte Carlo Recalculation

The SE-SBM Monte Carlo workflow used the following procedure:

1. Read baseline SE-SBM input and desirable-output variables.
2. Apply parameter perturbation to selected input and desirable-output variables.
3. Randomly sample one undesirable-output realization from the 1000 Crystal Ball environmental-impact simulations.
4. Pass the perturbed dataset to the SE-SBM solver.
5. Store the resulting LUE score for each decision-making unit.
6. Repeat the procedure for 1000 Monte Carlo iterations.

The cleaned wrapper script is provided as:

```text
02_SESBM_Monte_Carlo_wrapper_template.m
```

This script requires a SE-SBM solver that is equivalent to the model described in the manuscript. The original third-party solver is not redistributed.

## 6. Four-Quadrant Stability Analysis

The four-quadrant LUE-LES uncertainty analysis evaluates whether each region-year observation remains in the same LUE-LES quadrant under Monte Carlo simulations.

The script is:

```text
01_FourQuadrant_LUE_LES_Uncertainty.m
```

Required workbook sheets:

| Sheet | Required columns |
|---|---|
| `baseline` | `Region`, `Year`, `LUE_base`, `PLEF_base`, `LBC_base` |
| `LUE_MC` | `Region`, `Year`, `MC_1`, `MC_2`, ..., `MC_1000` |
| `PLEF_MC` | `Region`, `Year`, `MC_1`, `MC_2`, ..., `MC_1000` |
| `LBC_MC` | `Region`, `Year`, `MC_1`, `MC_2`, ..., `MC_1000` |

The script calculates:

- baseline LES, defined as `LBC / PLEF`;
- baseline four-quadrant classification;
- simulated four-quadrant classifications;
- quadrant-retention probability;
- frequency of each quadrant under Monte Carlo simulations;
- near-threshold observations.

## 7. Expected Outputs

| Output | Description |
|---|---|
| `Monte_Carlo_result.xlsx` | Simulated LUE scores from the SE-SBM Monte Carlo procedure |
| `Quadrant_uncertainty_results.xlsx` | Four-quadrant classification stability results |
| `Detailed_results` | Observation-level quadrant retention and threshold-distance results |
| `Summary` | Summary statistics for manuscript or supplementary information |
| `Unstable_observations` | Observations with lower quadrant-retention probability |
| `Representative_regions` | Selected representative regions for reporting |

## 8. Suggested Code Availability Statement

The uncertainty-analysis code and reproduction instructions are provided. Environmental impact and footprint uncertainty were implemented in Excel using Crystal Ball; therefore, the Excel workbooks, Crystal Ball assumption settings, and 1000 simulated outputs are provided rather than a standalone script for those spreadsheet calculations. The SE-SBM solver routine used for efficiency recalculation was obtained from a third party and is not redistributed because it is not licensed for public redistribution. To support reproducibility, we provide the Monte Carlo wrapper showing how perturbed inputs and undesirable-output samples were passed to the SE-SBM model, together with the model settings, processed Monte Carlo data, output results, and four-quadrant classification-stability code. The efficiency uncertainty analysis can be reproduced using any equivalent implementation of the specified SE-SBM model.

