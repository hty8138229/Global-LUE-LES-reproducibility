# Crystal Ball Excel Uncertainty Notes

This note documents how uncertainty was handled for the environmental impact and footprint calculations that were implemented in Excel.

## Materials to Provide

To make this part auditable, provide:

|Material|Purpose|
|-|-|
|Excel calculation workbook|Shows the deterministic formulas used to calculate environmental impact, PLEF, LBC, or related outputs|
|Crystal Ball assumption settings|Shows which parameters were perturbed and their assumed distributions|
|Crystal Ball forecast/output sheets|Provides the 1000 simulation outputs used in later SE-SBM and four-quadrant analyses|
|Notes sheet|Explains the perturbation range, distribution type, and output variables|

## Suggested Notes Text

The uncertainty analysis for environmental impact and footprint calculations was implemented in Excel using Crystal Ball. The deterministic calculations were formula-based, and Crystal Ball was used to perturb selected parameters and generate 1000 simulated output values. These outputs were then used as inputs for the SE-SBM efficiency uncertainty analysis and the four-quadrant LUE-LES stability analysis.

This uncertainty setting mainly represents parameter perturbation. It does not fully capture uncertainties related to MRIO structure, EXIOBASE aggregation, source-database inconsistencies, ReCiPe characterization factors, proxy-based machinery and energy estimates, or SE-SBM model specification.

